const entradaQuestao = document.getElementById('question');
const result = document.getElementById('result');

entradaQuestao.addEventListener("keypress", (e) => {
    if (entradaQuestao.value && e.key === "Enter")
       enviarPergunta();
});


const OPEN_API_KEY = "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"; /// chave pessoal da API ///

function enviarPergunta(){
    var sQuestion = entradaQuestao.value;


    fetch(`https://api.openai.com/v1/completions`, {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: "Bearer " + OPEN_API_KEY
            },
            body: JSON.stringify({
                model: "text-davinci-003",
                prompt: sQuestion,
                max_tokens: 2048,
                temperature: 1.0,
            }),
        })
        .then((response) => response.json())
        .then((json) => {
            if (result.value) result.value += "\n";

            if (json.error ?.message) {
                result.value += "Erro: " + json.error.message;
            } else if (json.choices ?.[0].text) {
                var text = json.choices[0].text || " Sem resposta";
                result.value += "Chat gpt: " + text;
            }
            result.scrollTop = result.scrollHeight;


        })
        .catch((error) => console.error("error", error))
        .finally(() => {
            entradaQuestao.value = "";
            entradaQuestao.disabled = true;
            entradaQuestao.focus();
        });

    if (result.value) result.value += "\n\n\n";
    result.value += `pergunta: ${sQuestion}`
    entradaQuestao.value = "carregando..."
    entradaQuestao.disabled = true;


    result.scrollTop = result.scrollHeight;

}


document.addEventListener("DOMContentLoaded", function(event) {
    document.getElementById("btn-atualizar").addEventListener("click", function() {   ///atualiza para nova pesquisa///
        location.reload();
    });
});

function salvarTexto() {
    var conteudo = document.getElementById("result").value;
    var blob = new Blob([conteudo], {type: "text/plain;charset=utf-8"});
    var leitor = new FileReader();                                          
    leitor.onload = function(event) {
      var linkDownload = document.createElement("a");         ///funçao que salva em TXT sua pesquisa///
      linkDownload.href = event.target.result;
      linkDownload.download = "chattGPT.txt";
      document.body.appendChild(linkDownload);
      linkDownload.click();
    };
    leitor.readAsDataURL(blob); 
}

